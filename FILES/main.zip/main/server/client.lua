repeat task.wait() until game:IsLoaded()
setfpscap(12)
spawn(function()
    Success, Error = pcall(function()
        local Response = (http_request or (syn and syn.request)) { Method = 'GET', Url = 'https://raw.githubusercontent.com/Achitsak/Nexus/refs/heads/main/XusMasterp.lua' }
        Function, Error = loadstring(Response.Body, 'XusMasterp')
        if not XusMasterp then
			Function()
			XusMasterp:Connect()
		end
    end)
end)