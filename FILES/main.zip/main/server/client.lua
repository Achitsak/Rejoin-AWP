repeat task.wait() until game:IsLoaded()

_G.Configs = {
    server_port = 2124,
}

task.spawn(function()
    x, p = pcall(function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/Achitsak/Nexus/refs/heads/main/Api-Loader-Masterp.lua"))()
    end)
    if not x then
        warn(`error: {tostring(p)}`)
    end
end)
