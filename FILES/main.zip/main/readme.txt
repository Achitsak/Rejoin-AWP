this is messages from master p.

if u have problem with program pls contact and gave feedback to me

i will fix, improv my program 

thank you.